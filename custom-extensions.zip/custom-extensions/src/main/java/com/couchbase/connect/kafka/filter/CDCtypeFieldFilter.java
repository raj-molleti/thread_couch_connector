package com.couchbase.connect.kafka.filter;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import com.couchbase.client.dcp.message.DcpMutationMessage;
import com.couchbase.client.deps.com.fasterxml.jackson.databind.JsonNode;
import com.couchbase.client.deps.com.fasterxml.jackson.databind.ObjectMapper;
import com.couchbase.client.deps.io.netty.buffer.ByteBuf;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CDCtypeFieldFilter implements Filter{
	
	private static final ObjectMapper MAPPER = new ObjectMapper();
	
	private  String typeList1=null;

	private static final Logger LOGGER = LoggerFactory.getLogger(CDCtypeFieldFilter.class);

	@Override
	public boolean pass(ByteBuf byteBuf) {
		
		FileReader reader;
		try {
			reader = new FileReader("E:\\Softwares\\kafka-connect\\couchbaseinc-kafka-connect\\couchbaseinc-kafka-connect-couchbase-4.0.0-dp.3\\etc\\filter-source.properties");
			
			//reader = new FileReader("\\home\\o3i\\filter-source.properties");
			
			Properties props = new Properties();
			props.load(reader);
			
			String type = props.getProperty("event.filter.class.typeList1.value");
			
			String[] typeArray = type.split(",");
			List<String>  typeList=(List) Arrays.asList(typeArray);
			
			if (DcpMutationMessage.is(byteBuf)) {
				 ByteBuf content = DcpMutationMessage.content(byteBuf);
		            if (content.readableBytes() > 0) {
		                byte[] bytes = new byte[content.readableBytes()];
		                content.getBytes(0, bytes);
		                try {
		                	LOGGER.info("====Logger======type===:posRuleHisType=====");
		                	if(typeList != null){
			                	LOGGER.info("====Logger====Inside If==type===:posRuleHisType====="+typeList1);
			                	JsonNode doc = MAPPER.readTree(bytes);
				                 return typeList.contains(doc.get("type").asText());			                	 
		                	}		                	
		                   
		                } catch (IOException e) {
		                    return false;
		                }
		            }
			}
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return false;
	}

}
